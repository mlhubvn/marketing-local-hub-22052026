<?php $__env->startComponent(theme_view('layouts.marketing', 'guest'), ['pageTitle' => $pageTitle]); ?>
    <?php
        $hasHtml = str_contains($pageContent, '<') && str_contains($pageContent, '>');
        $pageType = $pageType ?? 'html';
        $socialLinks = $socialLinks ?? [];
        $eyebrow = $pageType === 'social'
            ? __('Social directory')
            : (str_contains(strtolower($pageTitle), 'privacy')
                ? __('Privacy')
                : (str_contains(strtolower($pageTitle), 'term') ? __('Legal') : __('Information')));
        $pageTabs = [
            ['label' => __('Privacy Policy'), 'route' => 'guest.privacy-policy'],
            ['label' => __('Terms of Use'), 'route' => 'guest.terms-of-use'],
            ['label' => __('Social Pages'), 'route' => 'guest.social-pages'],
        ];
    ?>

    <style>
        .lb-static-eyebrow {
            border-color: color-mix(in srgb, var(--theme-border-color, #dfe9df) 88%, transparent);
            background: color-mix(in srgb, #ffb347 18%, #fff);
            color: #4f6907;
            box-shadow: 0 12px 34px -28px rgba(255, 95, 95, .45);
        }

        .lb-static-tabs {
            border-color: color-mix(in srgb, var(--theme-border-color, #dfe9df) 88%, transparent);
            background: rgba(255, 255, 252, .86);
            box-shadow: 0 16px 42px -32px rgba(16, 37, 31, .42);
        }

        .lb-static-tab {
            color: #66746d;
        }

        .lb-static-tab:hover {
            background: color-mix(in srgb, #ff5f5f 8%, #fff);
            color: #ff5f5f;
        }

        .lb-static-tab.is-active {
            background: #ff5f5f;
            color: #fff;
            box-shadow: 0 12px 28px -20px rgba(255, 95, 95, .72);
        }

        .lb-static-content a,
        .lb-static-content.prose a {
            color: #ff5f5f;
        }

        html[data-theme-resolved='dark'] .lb-static-eyebrow {
            border-color: rgba(225, 235, 22, .22) !important;
            background: rgba(184, 218, 22, .12) !important;
            color: #d9f75d !important;
        }

        html[data-theme-resolved='dark'] .lb-static-tabs,
        html[data-theme-resolved='dark'] .lb-static-tab:hover,
        html[data-theme-resolved='dark'] .lb-static-content [class*="bg-white"],
        html[data-theme-resolved='dark'] .guest-static-content [style*="#fff"],
        html[data-theme-resolved='dark'] .guest-static-content [style*="255, 255, 255"] {
            border-color: rgba(96, 165, 250, .22) !important;
            background: rgba(15, 23, 42, .82) !important;
            color: #e8eef7 !important;
        }

        html[data-theme-resolved='dark'] .lb-static-tab {
            color: #cbd5e1 !important;
        }

        html[data-theme-resolved='dark'] .lb-static-tab.is-active {
            background: #ff5f5f !important;
            color: #fff !important;
        }

        html[data-theme-resolved='dark'] .lb-static-content,
        html[data-theme-resolved='dark'] .guest-static-content {
            color: #cbd5e1 !important;
        }

        html[data-theme-resolved='dark'] .lb-static-content a,
        html[data-theme-resolved='dark'] .lb-static-content.prose a {
            color: #ffb347 !important;
        }
    </style>

    <section class="mlhub-shell mlhub-section pt-10">
        <div class="mx-auto max-w-5xl">
            <span class="lb-static-eyebrow inline-flex items-center gap-2 rounded-full border px-4 py-2 text-xs font-bold uppercase tracking-[0.18em]">
                <i class="fa-light fa-file-lines"></i>
                <?php echo e($eyebrow); ?>

            </span>
            <h1 class="mt-6 max-w-4xl text-5xl font-extrabold leading-[1.02] tracking-[-0.07em] text-slate-950 md:text-6xl"><?php echo e($pageTitle); ?></h1>
            <p class="mt-5 max-w-3xl text-base leading-8 text-slate-600">
                <?php echo e($pageType === 'social'
                    ? __('Public destinations connected to the MLHUB brand.')
                    : __('Clear public information for customers, buyers, and operators reviewing the platform.')); ?>

            </p>

            <div class="lb-static-tabs mt-8 flex flex-wrap gap-2 rounded-[1.25rem] border p-2">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $pageTabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <a href="<?php echo e(route($tab['route'])); ?>" class="lb-static-tab <?php echo e($routeName === $tab['route'] ? 'is-active' : ''); ?> rounded-full px-4 py-2 text-sm font-bold transition">
                        <?php echo e($tab['label']); ?>

                    </a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>

            <div class="mlhub-card mt-6 overflow-hidden rounded-[1.6rem]">
                <div class="border-b px-7 py-5 md:px-9" style="border-color: rgba(var(--theme-border-color-rgb),0.82);">
                    <p class="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-400"><?php echo e(__('Page content')); ?></p>
                </div>
                <div class="px-7 py-7 md:px-9 md:py-8">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pageType === 'social'): ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(trim($pageContent) !== ''): ?>
                            <div class="mb-8 max-w-3xl text-base leading-8 text-slate-600 whitespace-pre-line"><?php echo e($pageContent); ?></div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($socialLinks !== []): ?>
                            <div class="grid gap-4 md:grid-cols-2">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <a href="<?php echo e($link['url']); ?>" target="_blank" rel="noopener noreferrer" class="mlhub-card mlhub-hover-lift rounded-[1.2rem] p-5">
                                        <div class="flex items-center gap-4">
                                            <span class="flex h-12 w-12 shrink-0 items-center justify-center rounded-[0.9rem]" style="background: color-mix(in srgb, #ff5f5f 9%, #fff); color: #ff5f5f;">
                                                <i class="<?php echo e($link['icon']); ?> text-xl"></i>
                                            </span>
                                            <div class="min-w-0">
                                                <p class="font-extrabold text-slate-950"><?php echo e($link['label']); ?></p>
                                                <p class="mt-1 truncate text-sm text-slate-500"><?php echo e($link['url']); ?></p>
                                            </div>
                                        </div>
                                    </a>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="rounded-[1.25rem] border border-dashed px-6 py-12 text-center text-sm text-slate-500" style="border-color: rgba(var(--theme-border-color-rgb),0.9);"><?php echo e(__('No social links have been configured yet.')); ?></div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php elseif(trim($pageContent) === ''): ?>
                        <div class="rounded-[1.25rem] border border-dashed px-6 py-12 text-center text-sm text-slate-500" style="border-color: rgba(var(--theme-border-color-rgb),0.9);"><?php echo e(__('This page has not been configured yet.')); ?></div>
                    <?php elseif($hasHtml): ?>
                        <div class="lb-rich-content lb-static-content guest-static-content">
                            <?php echo $pageContent; ?>

                        </div>
                    <?php else: ?>
                        <div class="lb-static-content guest-static-content whitespace-pre-line text-sm leading-8 text-slate-600">
                            <?php echo e($pageContent); ?>

                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\LENOVO\Documents\GitHub\marketing-local-hub-22052026\resources\themes\guest\mlhubfrontend/resources/views/pages/static-page.blade.php ENDPATH**/ ?>