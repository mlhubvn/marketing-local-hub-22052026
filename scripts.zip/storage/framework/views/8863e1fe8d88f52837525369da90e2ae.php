
<div class="panel" style="margin-bottom:1rem;">
    <h3 style="margin:0 0 .6rem;"><?php echo e(__('Onboarding status')); ?></h3>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th><?php echo e(__('Vietnamese label')); ?></th>
                    <th><?php echo e(__('When it happens')); ?></th>
                    <th><?php echo e(__('What FizaHUB should do')); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><code>awaiting_consultant</code></td>
                    <td><?php echo e(__('Chờ tư vấn viên liên hệ')); ?></td>
                    <td><?php echo e(__('A Free account was created immediately; waiting for a consultant to reach out')); ?></td>
                    <td><?php echo e(__('Wait for MLHUB to contact the owner; do not recreate the request')); ?></td>
                </tr>
                <tr>
                    <td><code>needs_review</code></td>
                    <td><?php echo e(__('Cần kiểm tra')); ?></td>
                    <td><?php echo e(__('Duplicate email / tax code / business license (the account is still created)')); ?></td>
                    <td><?php echo e(__('Do not keep recreating the same request; ask MLHUB to process the ticket')); ?></td>
                </tr>
                <tr>
                    <td><code>ready</code></td>
                    <td><?php echo e(__('Sẵn sàng sử dụng')); ?></td>
                    <td><?php echo e(__('Configuration finished; one-time login is now allowed')); ?></td>
                    <td><?php echo e(__('You may call Package, Dashboard, Support, and One-time Login')); ?></td>
                </tr>
                <tr>
                    <td><code>completed</code></td>
                    <td><?php echo e(__('Hoàn tất')); ?></td>
                    <td><?php echo e(__('Onboarding was handed over and completed')); ?></td>
                    <td><?php echo e(__('Use the account normally')); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="panel" style="margin-bottom:1rem;">
    <h3 style="margin:0 0 .6rem;"><?php echo e(__('Onboarding current_step')); ?></h3>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th><?php echo e(__('Vietnamese label')); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr><td><code>consultant_contact</code></td><td><?php echo e(__('Chờ tư vấn viên liên hệ')); ?></td></tr>
                <tr><td><code>needs_review</code></td><td><?php echo e(__('Đang rà soát trùng dữ liệu')); ?></td></tr>
                <tr><td><code>ready</code></td><td><?php echo e(__('Sẵn sàng sử dụng')); ?></td></tr>
                <tr><td><code>completed</code></td><td><?php echo e(__('Hoàn tất')); ?></td></tr>
            </tbody>
        </table>
    </div>
</div>

<div class="grid-2" style="margin-bottom:1rem;">
    <div class="panel">
        <h3 style="margin:0 0 .6rem;"><?php echo e(__('Support ticket status')); ?></h3>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Code</th>
                        <th><?php echo e(__('Vietnamese label')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td><code>open</code></td><td><?php echo e(__('Đang mở')); ?></td></tr>
                    <tr><td><code>resolved</code></td><td><?php echo e(__('Đã xử lý')); ?></td></tr>
                    <tr><td><code>closed</code></td><td><?php echo e(__('Đã đóng')); ?></td></tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="panel">
        <h3 style="margin:0 0 .6rem;"><?php echo e(__('Package status')); ?></h3>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Code</th>
                        <th><?php echo e(__('Vietnamese label')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td><code>active</code></td><td><?php echo e(__('Đang hoạt động')); ?></td></tr>
                    <tr><td><code>inactive</code></td><td><?php echo e(__('Tạm ngừng')); ?></td></tr>
                    <tr><td><code>expired</code></td><td><?php echo e(__('Hết hạn')); ?></td></tr>
                    <tr><td><code>none</code></td><td><?php echo e(__('Chưa có gói')); ?></td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="panel">
    <h3 style="margin:0 0 .6rem;"><?php echo e(__('Error codes')); ?></h3>
    <p class="muted" style="margin:0 0 .6rem;"><?php echo e(__('API error codes stay English. Vietnamese labels below are for documentation only.')); ?></p>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th><?php echo e(__('Vietnamese label')); ?></th>
                    <th><?php echo e(__('How to fix')); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><code>invalid_partner_header</code></td>
                    <td><?php echo e(__('Header đối tác không hợp lệ')); ?></td>
                    <td><?php echo e(__('Check X-Partner and X-Request-Id')); ?></td>
                </tr>
                <tr>
                    <td><code>invalid_partner_token</code></td>
                    <td><?php echo e(__('Token đối tác không hợp lệ')); ?></td>
                    <td><?php echo e(__('Check partner_token')); ?></td>
                </tr>
                <tr>
                    <td><code>validation_failed</code></td>
                    <td><?php echo e(__('Dữ liệu không hợp lệ')); ?></td>
                    <td><?php echo e(__('Read error.details and fix Body/Params')); ?></td>
                </tr>
                <tr>
                    <td><code>integration_not_found</code></td>
                    <td><?php echo e(__('Chưa có mapping MLHUB cho business này')); ?></td>
                    <td><?php echo e(__('Run onboarding first or check external_business_id')); ?></td>
                </tr>
                <tr>
                    <td><code>resource_not_found</code></td>
                    <td><?php echo e(__('Không tìm thấy dữ liệu')); ?></td>
                    <td><?php echo e(__('Check request_id / ticket_id / external_business_id')); ?></td>
                </tr>
                <tr>
                    <td><code>idempotency_conflict</code></td>
                    <td><?php echo e(__('Idempotency-Key bị dùng lại với body khác')); ?></td>
                    <td><?php echo e(__('Create a new Idempotency-Key')); ?></td>
                </tr>
                <tr>
                    <td><code>idempotency_in_progress</code></td>
                    <td><?php echo e(__('Request cùng Idempotency-Key đang xử lý')); ?></td>
                    <td><?php echo e(__('Wait and retry')); ?></td>
                </tr>
                <tr>
                    <td><code>ticket_not_open</code></td>
                    <td><?php echo e(__('Ticket đã đóng hoặc đã xử lý')); ?></td>
                    <td><?php echo e(__('Do not send a new message to this ticket')); ?></td>
                </tr>
                <tr>
                    <td><code>onboarding_not_ready</code></td>
                    <td><?php echo e(__('Tài khoản đang chờ tư vấn viên MLHUB hoàn tất cấu hình.')); ?></td>
                    <td><?php echo e(__('Wait for status ready/completed before calling one-time login')); ?></td>
                </tr>
                <tr>
                    <td><code>rate_limit_exceeded</code></td>
                    <td><?php echo e(__('Gọi API quá nhiều')); ?></td>
                    <td><?php echo e(__('Wait about one minute')); ?></td>
                </tr>
                <tr>
                    <td><code>partner_api_error</code></td>
                    <td><?php echo e(__('Lỗi hệ thống API partner')); ?></td>
                    <td><?php echo e(__('Ask MLHUB to check logs')); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH C:\Users\LENOVO\Documents\GitHub\marketing-local-hub-22052026\modules\APIPartnerFizaHUB\Providers/../Resources/views/partials/status-tables.blade.php ENDPATH**/ ?>