<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="<?php echo e(current_locale_direction()); ?>">
<head>
    <?php echo $__env->make(theme_view('partials.head', 'guest'), ['title' => $pageTitle ?? null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.9/dist/cdn.min.js"></script>
</head>
<?php
    $languages = available_languages();
    $options = app(\Modules\AdminSettings\Support\OptionStore::class);
    $settingsTitle = trim((string) $options->get('website_title', ''));
    $siteTitle = $settingsTitle !== '' && ! str_contains(strtolower($settingsTitle), 'stackposts') ? $settingsTitle : 'MLHUB AI';
    $siteLogoDark = trim((string) ($options->get('website_logo_brand_dark')
        ?: $options->get('website_logo_dark')
        ?: $options->get('website_logo')
        ?: config('mlhub.site.brand_logo_dark', 'img/logo-brand-dark.svg')));
    $siteLogoLight = trim((string) ($options->get('website_logo_brand_light')
        ?: $options->get('website_logo_light')
        ?: $options->get('website_logo')
        ?: config('mlhub.site.brand_logo_light', 'img/logo-brand-light.svg')));
    $siteLogoDarkUrl = url($siteLogoDark);
    $siteLogoLightUrl = url($siteLogoLight);
    $siteDescription = trim((string) $options->get('website_description', ''));
    $siteDescription = $siteDescription !== '' ? $siteDescription : __('AI-powered local marketing tools for reviews, bookings, leads, coupons, feedback, QR campaign pages, and reports.');
    $signupEnabled = (string) $options->get('auth_signup_page_status', '1') === '1';
    $contactEmail = trim((string) $options->get('contact_email', ''));
    $homeUrl = route('home');
    $footerLegal = [
        ['label' => __('Security policy'), 'href' => route('guest.privacy-policy')],
        ['label' => __('Terms of Use'), 'href' => route('guest.terms-of-use')],
    ];
?>
<body class="min-h-screen antialiased scroll-smooth" style="font-family: var(--theme-font-sans); color: #242320; background: #fbfaf5;">
    <div class="relative isolate min-h-screen overflow-x-clip">
        <header
            x-data="{
                open: false,
                scrolled: false,
                mode: window.themeMode?.getMode?.() || 'dark',
                resolved: window.themeMode?.getResolved?.() || 'dark',
                syncTheme(state = null) {
                    this.mode = state?.mode || window.themeMode?.getMode?.() || 'dark';
                    this.resolved = state?.resolved || window.themeMode?.getResolved?.() || 'dark';
                },
                toggleTheme() {
                    this.syncTheme(window.themeMode?.toggle?.());
                }
            }"
            x-init="
                scrolled = window.scrollY > 12;
                syncTheme();
                window.addEventListener('scroll', () => { scrolled = window.scrollY > 12 }, { passive: true });
                window.addEventListener('theme-mode-changed', (event) => syncTheme(event.detail));
            "
            class="fixed left-0 right-0 top-3 z-50"
        >
            <div
                class="mx-auto rounded-[1.45rem] border bg-white/82 px-3.5 shadow-[0_18px_52px_-46px_rgba(36,35,32,0.55)] backdrop-blur-2xl transition"
                style="width: min(1160px, calc(100% - 40px)); border-color: rgba(232,229,220,0.86);"
                x-bind:class="scrolled ? 'bg-white/94 shadow-[0_18px_50px_-40px_rgba(36,35,32,0.42)]' : ''"
            >
                <div>
                    <div class="flex min-h-[3.5rem] items-center justify-between gap-6">
                        <a href="<?php echo e(route('home')); ?>" class="group flex min-w-0 items-center no-theme-link">
                            <span class="relative inline-flex h-10 shrink-0 items-center justify-center overflow-hidden">
                                <img class="theme-logo-dark h-9 w-auto max-w-[11rem] object-contain" src="<?php echo e($siteLogoDarkUrl); ?>" alt="<?php echo e($siteTitle); ?>">
                                <img class="theme-logo-light h-9 w-auto max-w-[11rem] object-contain" src="<?php echo e($siteLogoLightUrl); ?>" alt="<?php echo e($siteTitle); ?>">
                            </span>
                        </a>

                        <?php echo $__env->make(theme_view('partials.marketing-nav', 'guest'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div class="hidden items-center gap-2 lg:flex">
                            <button
                                type="button"
                                x-on:click="toggleTheme()"
                                class="inline-flex h-10 w-10 items-center justify-center rounded-full border bg-white/74 text-neutral-600 shadow-sm transition hover:bg-neutral-50"
                                style="border-color: #e8e5dc;"
                                x-bind:aria-label="resolved === 'dark' ? <?php echo \Illuminate\Support\Js::from(__('Switch to light mode'))->toHtml() ?> : <?php echo \Illuminate\Support\Js::from(__('Switch to dark mode'))->toHtml() ?>"
                                x-bind:title="resolved === 'dark' ? <?php echo \Illuminate\Support\Js::from(__('Switch to light mode'))->toHtml() ?> : <?php echo \Illuminate\Support\Js::from(__('Switch to dark mode'))->toHtml() ?>"
                            >
                                <i class="fa-light text-sm" x-bind:class="resolved === 'dark' ? 'fa-sun-bright' : 'fa-moon-stars'"></i>
                            </button>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($languages->isNotEmpty()): ?>
                                <?php $activeLanguage = $languages->firstWhere('code', app()->getLocale()) ?? $languages->first(); ?>
                                <div x-data="{ openLanguage: false }" class="relative">
                                    <button type="button" x-on:click="openLanguage = ! openLanguage" x-on:click.outside="openLanguage = false" class="inline-flex h-10 items-center gap-2 rounded-full border bg-white/74 px-3 text-sm font-bold text-neutral-600 shadow-sm" style="border-color: #e8e5dc;">
                                        <span class="<?php echo e(language_flag_class($activeLanguage ?? app()->getLocale())); ?> rounded-sm text-[17px]"></span>
                                    </button>
                                    <div x-cloak x-show="openLanguage" x-transition.origin.top.right class="absolute right-0 z-30 mt-3 w-56 overflow-hidden rounded-[1rem] border bg-white p-2 shadow-xl" style="border-color: rgba(var(--theme-border-color-rgb),0.85);">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                            <?php $isActiveLanguage = app()->getLocale() === $language->code; ?>
                                            <a href="<?php echo e(route('language.switch', $language->code)); ?>" class="flex items-center gap-3 rounded-[0.8rem] px-3 py-2.5 text-sm font-semibold transition <?php echo e($isActiveLanguage ? 'text-white' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-950'); ?>" <?php if($isActiveLanguage): ?> style="background:#ff5f5f;" <?php endif; ?>>
                                                <span class="<?php echo e(language_flag_class($language)); ?> rounded-sm text-[17px]"></span>
                                                <span class="flex-1"><?php echo e($language->name ?? strtoupper((string) $language->code)); ?></span>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isActiveLanguage): ?>
                                                    <i class="fa-light fa-check text-xs"></i>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </a>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                                <a href="<?php echo e(route('portal.dashboard')); ?>" class="inline-flex h-10 items-center justify-center rounded-full px-5 text-sm font-black text-white shadow-[0_14px_28px_-20px_rgba(255,95,95,0.62)]" style="background:#ff5f5f;"><?php echo e(__('Dashboard')); ?></a>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" class="inline-flex h-10 items-center justify-center rounded-full px-4 text-sm font-bold text-neutral-500 transition hover:bg-neutral-100 hover:text-neutral-950"><?php echo e(__('Log in')); ?></a>
                                <a href="<?php echo e($signupEnabled ? route('register') : route('login')); ?>" class="inline-flex h-10 items-center justify-center rounded-full px-5 text-sm font-black text-white shadow-[0_14px_28px_-20px_rgba(255,95,95,0.62)]" style="background:#ff5f5f;"><?php echo e(__('Sign up')); ?></a>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <button type="button" x-on:click="open = ! open" class="inline-flex h-9 w-9 items-center justify-center rounded-full border bg-white text-neutral-700 shadow-sm lg:hidden" style="border-color: #e8e5dc;">
                            <i class="fa-light fa-bars"></i>
                        </button>
                    </div>

                    <div x-cloak x-show="open" x-transition class="border-t pb-4 pt-3 lg:hidden" style="border-color: rgba(var(--theme-border-color-rgb),0.75);">
                        <?php echo $__env->make(theme_view('partials.marketing-nav-mobile', 'guest'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <div class="mt-3 grid gap-2 sm:grid-cols-2">
                            <button
                                type="button"
                                x-on:click="toggleTheme()"
                                class="mlhub-button-secondary inline-flex items-center justify-center rounded-[var(--theme-button-radius)] px-4 py-3 text-sm font-semibold sm:col-span-2"
                            >
                                <i class="fa-light mr-2" x-bind:class="resolved === 'dark' ? 'fa-sun-bright' : 'fa-moon-stars'"></i>
                                <span x-text="resolved === 'dark' ? <?php echo \Illuminate\Support\Js::from(__('Light mode'))->toHtml() ?> : <?php echo \Illuminate\Support\Js::from(__('Dark mode'))->toHtml() ?>"></span>
                            </button>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                                <a href="<?php echo e(route('portal.dashboard')); ?>" class="mlhub-button-primary inline-flex items-center justify-center rounded-[var(--theme-button-radius)] px-4 py-3 text-sm font-bold"><?php echo e(__('Dashboard')); ?></a>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" class="mlhub-button-secondary inline-flex items-center justify-center rounded-[var(--theme-button-radius)] px-4 py-3 text-sm font-semibold"><?php echo e(__('Log in')); ?></a>
                                <a href="<?php echo e($signupEnabled ? route('register') : route('login')); ?>" class="mlhub-button-primary inline-flex items-center justify-center rounded-[var(--theme-button-radius)] px-4 py-3 text-sm font-bold"><?php echo e(__('Sign up')); ?></a>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                    </div>
            </div>
        </header>

        <main class="pt-20">
            <?php if (! empty(trim($__env->yieldContent('content')))): ?>
                <?php echo $__env->yieldContent('content'); ?>
            <?php else: ?>
                <?php echo e($slot ?? ''); ?>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </main>

        <footer class="border-t bg-[#fbfaf5]" style="border-color: #e8e5dc;">
            <div class="mx-auto py-14" style="width: min(1120px, calc(100% - 40px));">
                <div class="grid gap-10 lg:grid-cols-[1.1fr_0.8fr_0.8fr_0.8fr]">
                    <div>
                        <a href="<?php echo e(route('home')); ?>" class="inline-flex items-center no-theme-link">
                            <span class="inline-flex h-10 shrink-0 items-center justify-center overflow-hidden">
                                <img class="theme-logo-dark h-9 w-auto max-w-[11rem] object-contain" src="<?php echo e($siteLogoDarkUrl); ?>" alt="<?php echo e($siteTitle); ?>">
                                <img class="theme-logo-light h-9 w-auto max-w-[11rem] object-contain" src="<?php echo e($siteLogoLightUrl); ?>" alt="<?php echo e($siteTitle); ?>">
                            </span>
                        </a>
                        <p class="mt-4 max-w-md text-sm leading-7 text-neutral-500"><?php echo e(__('AI-powered local marketing tools for reviews, bookings, leads, coupons, feedback, QR campaign pages, and reports.')); ?></p>
                    </div>

                    <div>
                        <p class="text-xs font-black uppercase tracking-[0.18em] text-neutral-400"><?php echo e(__('Product')); ?></p>
                        <div class="mt-4 grid gap-3 text-sm font-bold text-neutral-600">
                            <a href="<?php echo e(route('guest.about')); ?>" class="hover:text-teal-700"><?php echo e(__('About MLHUB')); ?></a>
                            <a href="<?php echo e(route('guest.solutions')); ?>" class="hover:text-teal-700"><?php echo e(__('All-in-one solutions')); ?></a>
                            <a href="<?php echo e($homeUrl); ?>#features" class="hover:text-teal-700"><?php echo e(__('Core features')); ?></a>
                            <a href="<?php echo e(route('guest.pricing')); ?>" class="hover:text-teal-700"><?php echo e(__('Pricing and services')); ?></a>
                            <a href="<?php echo e(route('home')); ?>#how-it-works" class="hover:text-teal-700"><?php echo e(__('How it works')); ?></a>
                            <a href="<?php echo e(route('guest.blogs')); ?>" class="hover:text-teal-700"><?php echo e(__('News and guides')); ?></a>
                        </div>
                    </div>

                    <div>
                        <p class="text-xs font-black uppercase tracking-[0.18em] text-neutral-400"><?php echo e(__('Links')); ?></p>
                        <div class="mt-4 grid gap-3 text-sm font-bold text-neutral-600">
                            <a href="<?php echo e(route('guest.contact')); ?>" class="hover:text-teal-700"><?php echo e(__('Support contact')); ?></a>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $footerLegal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <a href="<?php echo e($item['href']); ?>" class="hover:text-teal-700"><?php echo e($item['label']); ?></a>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($contactEmail !== ''): ?>
                                <a href="mailto:<?php echo e($contactEmail); ?>" class="hover:text-teal-700"><?php echo e($contactEmail); ?></a>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>

                    <div>
                        <p class="text-xs font-black uppercase tracking-[0.18em] text-neutral-400"><?php echo e(__('Built for')); ?></p>
                        <div class="mt-4 flex flex-wrap gap-2">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [__('Reviews'), __('Bookings'), __('Leads'), __('Reports'), __('QR campaigns')]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $badge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <span class="rounded-full border bg-white px-3 py-1.5 text-[11px] font-bold text-neutral-600 shadow-sm" style="border-color: #e8e5dc;"><?php echo e($badge); ?></span>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                        <a href="<?php echo e(route('login')); ?>" class="mt-5 inline-flex h-11 items-center justify-center rounded-full px-5 text-sm font-bold text-white shadow-[0_14px_28px_-20px_rgba(255,95,95,0.62)]" style="background:#ff5f5f;">
                            <?php echo e(__('Start Free Trial')); ?>

                        </a>
                    </div>
                </div>
            </div>
            <div class="relative border-t overflow-hidden" style="border-color: #e8e5dc;">
                <div class="relative mx-auto flex flex-col gap-3 py-6 text-xs font-bold text-neutral-400 sm:flex-row sm:items-center sm:justify-between" style="width: min(1120px, calc(100% - 40px));">
                    <p>&copy; <?php echo e(date('Y')); ?> <?php echo e($siteTitle); ?>. <?php echo e(__('All rights reserved.')); ?></p>
                    <p><?php echo e(__('AI-powered local marketing tools in one SaaS.')); ?></p>
                </div>
            </div>
        </footer>
    </div>
    <?php echo $__env->make(theme_view('partials.gdpr-consent', 'guest'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make(theme_view('partials.embed-code-body', 'guest'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\LENOVO\Documents\GitHub\marketing-local-hub-22052026\resources\themes\guest\mlhubfrontend/resources/views/layouts/marketing.blade.php ENDPATH**/ ?>