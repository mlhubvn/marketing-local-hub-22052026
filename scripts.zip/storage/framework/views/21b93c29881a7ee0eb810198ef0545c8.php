<?php
    $homeUrl = route('home');
    $aboutUrl = route('guest.about');
    $homeNavSections = [
        ['label' => __('Platform overview'), 'hash' => '#hero', 'icon' => 'fa-house'],
        ['label' => __('Growth workflow'), 'hash' => '#workflow', 'icon' => 'fa-diagram-project'],
        ['label' => __('Core features'), 'hash' => '#features', 'icon' => 'fa-grid-2'],
        ['label' => __('How it works'), 'hash' => '#how-it-works', 'icon' => 'fa-route'],
        ['label' => __('Real-world proof'), 'hash' => '#product-proof', 'icon' => 'fa-browser'],
        ['label' => __('Flexible expansion'), 'hash' => '#modules', 'icon' => 'fa-layer-group'],
        ['label' => __('Launch campaigns'), 'hash' => '#get-started', 'icon' => 'fa-rocket-launch'],
    ];
    $aboutNavSections = [
        ['label' => __('About MLHUB AI'), 'hash' => '#mlhub-ai-mcp', 'icon' => 'fa-robot'],
        ['label' => __('What is MLHUB?'), 'hash' => '#about-what', 'icon' => 'fa-circle-info'],
        ['label' => __('Vision & Mission'), 'hash' => '#about-vision', 'icon' => 'fa-compass'],
        ['label' => __('Market challenges'), 'hash' => '#about-pain', 'icon' => 'fa-triangle-exclamation'],
        ['label' => __('Comprehensive solutions'), 'hash' => '#about-solutions', 'icon' => 'fa-lightbulb'],
        ['label' => __('Productivity digitization'), 'hash' => '#about-benefits', 'icon' => 'fa-gem'],
        ['label' => __('Revenue replication'), 'hash' => '#about-journey', 'icon' => 'fa-road'],
    ];
    $resourceNavSections = [
        ['label' => __('Solutions'), 'href' => route('guest.solutions'), 'icon' => 'fa-puzzle-piece'],
        ['label' => __('Pricing'), 'href' => route('guest.pricing'), 'icon' => 'fa-credit-card'],
        ['label' => __('Blog'), 'href' => route('guest.blogs'), 'icon' => 'fa-newspaper'],
        ['label' => __('FAQs (FAQ)'), 'href' => route('guest.faqs'), 'icon' => 'fa-circle-question'],
        ['label' => __('Business directory'), 'href' => route('guest.directory'), 'icon' => 'fa-store'],
    ];
    $homeNavActive = request()->routeIs('home');
    $aboutNavActive = request()->routeIs('guest.about');
    $resourcesNavActive = request()->routeIs('guest.solutions')
        || request()->routeIs('guest.pricing')
        || request()->routeIs('guest.blogs')
        || request()->routeIs('guest.blog*')
        || request()->routeIs('guest.faqs')
        || request()->routeIs('guest.directory');
    $contactNavActive = request()->routeIs('guest.contact');
?>

<nav class="hidden items-center gap-2 lg:flex">
    <div
        x-data="{ open: false }"
        class="relative"
        x-on:mouseenter="open = true"
        x-on:mouseleave="open = false"
    >
        <a
            href="<?php echo e($homeUrl); ?>#hero"
            class="inline-flex items-center gap-1.5 rounded-full px-4 py-2.5 text-sm font-bold transition <?php echo e($homeNavActive ? 'bg-neutral-100 text-neutral-950' : 'text-neutral-500 hover:bg-neutral-50 hover:text-neutral-950'); ?>"
        >
            <?php echo e(__('Home')); ?>

            <i class="fa-light fa-chevron-down text-[10px] opacity-70"></i>
        </a>
        <div
            x-cloak
            x-show="open"
            x-transition:enter="transition ease-out duration-150"
            x-transition:enter-start="opacity-0 -translate-y-1"
            x-transition:enter-end="opacity-100 translate-y-0"
            x-transition:leave="transition ease-in duration-100"
            x-transition:leave-start="opacity-100 translate-y-0"
            x-transition:leave-end="opacity-0 -translate-y-1"
            class="absolute left-0 z-40 mt-2 w-[17.5rem] overflow-hidden rounded-[1.1rem] border bg-white p-2 shadow-xl"
            style="border-color: rgba(232,229,220,0.95);"
        >
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $homeNavSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a
                    href="<?php echo e($homeUrl); ?><?php echo e($section['hash']); ?>"
                    class="flex items-center gap-3 rounded-[0.85rem] px-3 py-2.5 text-sm font-semibold text-neutral-600 transition hover:bg-neutral-50 hover:text-neutral-950"
                >
                    <span class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg" style="background: color-mix(in srgb, #ff5f5f 10%, #fff); color: #ff5f5f;">
                        <i class="fa-light <?php echo e($section['icon']); ?> text-sm"></i>
                    </span>
                    <span><?php echo e($section['label']); ?></span>
                </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>

    <div
        x-data="{ open: false }"
        class="relative"
        x-on:mouseenter="open = true"
        x-on:mouseleave="open = false"
    >
        <a
            href="<?php echo e($aboutUrl); ?>#about-what"
            class="inline-flex items-center gap-1.5 rounded-full px-4 py-2.5 text-sm font-bold transition <?php echo e($aboutNavActive ? 'bg-neutral-100 text-neutral-950' : 'text-neutral-500 hover:bg-neutral-50 hover:text-neutral-950'); ?>"
        >
            <?php echo e(__('About')); ?>

            <i class="fa-light fa-chevron-down text-[10px] opacity-70"></i>
        </a>
        <div
            x-cloak
            x-show="open"
            x-transition:enter="transition ease-out duration-150"
            x-transition:enter-start="opacity-0 -translate-y-1"
            x-transition:enter-end="opacity-100 translate-y-0"
            x-transition:leave="transition ease-in duration-100"
            x-transition:leave-start="opacity-100 translate-y-0"
            x-transition:leave-end="opacity-0 -translate-y-1"
            class="absolute left-0 z-40 mt-2 w-[17.5rem] overflow-hidden rounded-[1.1rem] border bg-white p-2 shadow-xl"
            style="border-color: rgba(232,229,220,0.95);"
        >
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $aboutNavSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a
                    href="<?php echo e($aboutUrl); ?><?php echo e($section['hash']); ?>"
                    class="flex items-center gap-3 rounded-[0.85rem] px-3 py-2.5 text-sm font-semibold text-neutral-600 transition hover:bg-neutral-50 hover:text-neutral-950"
                >
                    <span class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg" style="background: color-mix(in srgb, #ff5f5f 10%, #fff); color: #ff5f5f;">
                        <i class="fa-light <?php echo e($section['icon']); ?> text-sm"></i>
                    </span>
                    <span><?php echo e($section['label']); ?></span>
                </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>

    <div
        x-data="{ open: false }"
        class="relative"
        x-on:mouseenter="open = true"
        x-on:mouseleave="open = false"
    >
        <a
            href="<?php echo e(route('guest.pricing')); ?>"
            class="inline-flex items-center gap-1.5 rounded-full px-4 py-2.5 text-sm font-bold transition <?php echo e($resourcesNavActive ? 'bg-neutral-100 text-neutral-950' : 'text-neutral-500 hover:bg-neutral-50 hover:text-neutral-950'); ?>"
        >
            <?php echo e(__('Resources')); ?>

            <i class="fa-light fa-chevron-down text-[10px] opacity-70"></i>
        </a>
        <div
            x-cloak
            x-show="open"
            x-transition:enter="transition ease-out duration-150"
            x-transition:enter-start="opacity-0 -translate-y-1"
            x-transition:enter-end="opacity-100 translate-y-0"
            x-transition:leave="transition ease-in duration-100"
            x-transition:leave-start="opacity-100 translate-y-0"
            x-transition:leave-end="opacity-0 -translate-y-1"
            class="absolute left-0 z-40 mt-2 w-[15.5rem] overflow-hidden rounded-[1.1rem] border bg-white p-2 shadow-xl"
            style="border-color: rgba(232,229,220,0.95);"
        >
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $resourceNavSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a
                    href="<?php echo e($section['href']); ?>"
                    class="flex items-center gap-3 rounded-[0.85rem] px-3 py-2.5 text-sm font-semibold text-neutral-600 transition hover:bg-neutral-50 hover:text-neutral-950"
                >
                    <span class="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg" style="background: color-mix(in srgb, #ff5f5f 10%, #fff); color: #ff5f5f;">
                        <i class="fa-light <?php echo e($section['icon']); ?> text-sm"></i>
                    </span>
                    <span><?php echo e($section['label']); ?></span>
                </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>

    <a href="<?php echo e(route('guest.contact')); ?>" class="rounded-full px-4 py-2.5 text-sm font-bold transition <?php echo e($contactNavActive ? 'bg-neutral-100 text-neutral-950' : 'text-neutral-500 hover:bg-neutral-50 hover:text-neutral-950'); ?>">
        <?php echo e(__('Contact')); ?>

    </a>
</nav>
<?php /**PATH C:\Users\LENOVO\Documents\GitHub\marketing-local-hub-22052026\resources\themes\guest\mlhubfrontend/resources/views/partials/marketing-nav.blade.php ENDPATH**/ ?>