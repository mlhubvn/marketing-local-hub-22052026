<?php
    $homeUrl = route('home');
    $aboutUrl = route('guest.about');
    $homeNavActive = request()->routeIs('home');
    $aboutNavActive = request()->routeIs('guest.about');
    $homeNavSections = [
        ['label' => __('Platform overview'), 'hash' => '#hero'],
        ['label' => __('Growth workflow'), 'hash' => '#workflow'],
        ['label' => __('Core features'), 'hash' => '#features'],
        ['label' => __('How it works'), 'hash' => '#how-it-works'],
        ['label' => __('Real-world proof'), 'hash' => '#product-proof'],
        ['label' => __('Flexible expansion'), 'hash' => '#modules'],
        ['label' => __('Launch campaigns'), 'hash' => '#get-started'],
    ];
    $aboutNavSections = [
        ['label' => __('About MLHUB AI'), 'hash' => '#mlhub-ai-mcp'],
        ['label' => __('What is MLHUB?'), 'hash' => '#about-what'],
        ['label' => __('Vision & Mission'), 'hash' => '#about-vision'],
        ['label' => __('Market challenges'), 'hash' => '#about-pain'],
        ['label' => __('Comprehensive solutions'), 'hash' => '#about-solutions'],
        ['label' => __('Productivity digitization'), 'hash' => '#about-benefits'],
        ['label' => __('Revenue replication'), 'hash' => '#about-journey'],
    ];
    $resourceNavSections = [
        ['label' => __('Solutions'), 'href' => route('guest.solutions')],
        ['label' => __('Pricing'), 'href' => route('guest.pricing')],
        ['label' => __('Blog'), 'href' => route('guest.blogs')],
        ['label' => __('FAQs (FAQ)'), 'href' => route('guest.faqs')],
        ['label' => __('Business directory'), 'href' => route('guest.directory')],
    ];
    $resourcesNavActive = request()->routeIs('guest.solutions')
        || request()->routeIs('guest.pricing')
        || request()->routeIs('guest.blogs')
        || request()->routeIs('guest.blog*')
        || request()->routeIs('guest.faqs')
        || request()->routeIs('guest.directory');
    $contactNavActive = request()->routeIs('guest.contact');
?>

<nav class="grid gap-1" x-data="{ homeOpen: false, aboutOpen: false, resourcesOpen: false }">
    <div>
        <button
            type="button"
            x-on:click="homeOpen = ! homeOpen"
            class="flex w-full items-center justify-between rounded-[0.95rem] px-3 py-2.5 text-sm font-bold <?php echo e($homeNavActive ? 'text-white' : 'text-slate-700'); ?>"
            <?php if($homeNavActive): ?> style="background:#ff5f5f;" <?php endif; ?>
        >
            <span><?php echo e(__('Home')); ?></span>
            <i class="fa-light text-xs" x-bind:class="homeOpen ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
        </button>
        <div x-cloak x-show="homeOpen" x-transition class="mt-1 grid gap-0.5 pl-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $homeNavSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="<?php echo e($homeUrl); ?><?php echo e($section['hash']); ?>" class="rounded-[0.85rem] px-3 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-50"><?php echo e($section['label']); ?></a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>

    <div>
        <button
            type="button"
            x-on:click="aboutOpen = ! aboutOpen"
            class="flex w-full items-center justify-between rounded-[0.95rem] px-3 py-2.5 text-sm font-bold <?php echo e($aboutNavActive ? 'text-white' : 'text-slate-700 hover:bg-slate-50'); ?>"
            <?php if($aboutNavActive): ?> style="background:#ff5f5f;" <?php endif; ?>
        >
            <span><?php echo e(__('About')); ?></span>
            <i class="fa-light text-xs" x-bind:class="aboutOpen ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
        </button>
        <div x-cloak x-show="aboutOpen" x-transition class="mt-1 grid gap-0.5 pl-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $aboutNavSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="<?php echo e($aboutUrl); ?><?php echo e($section['hash']); ?>" class="rounded-[0.85rem] px-3 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-50"><?php echo e($section['label']); ?></a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>

    <div>
        <button
            type="button"
            x-on:click="resourcesOpen = ! resourcesOpen"
            class="flex w-full items-center justify-between rounded-[0.95rem] px-3 py-2.5 text-sm font-bold <?php echo e($resourcesNavActive ? 'text-white' : 'text-slate-700 hover:bg-slate-50'); ?>"
            <?php if($resourcesNavActive): ?> style="background:#ff5f5f;" <?php endif; ?>
        >
            <span><?php echo e(__('Resources')); ?></span>
            <i class="fa-light text-xs" x-bind:class="resourcesOpen ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
        </button>
        <div x-cloak x-show="resourcesOpen" x-transition class="mt-1 grid gap-0.5 pl-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $resourceNavSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="<?php echo e($section['href']); ?>" class="rounded-[0.85rem] px-3 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-50"><?php echo e($section['label']); ?></a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>

    <a
        href="<?php echo e(route('guest.contact')); ?>"
        class="rounded-[0.95rem] px-3 py-2.5 text-sm font-bold <?php echo e($contactNavActive ? 'text-white' : 'text-slate-600 hover:bg-slate-50'); ?>"
        <?php if($contactNavActive): ?> style="background:#ff5f5f;" <?php endif; ?>
    ><?php echo e(__('Contact')); ?></a>
</nav>
<?php /**PATH C:\Users\LENOVO\Documents\GitHub\marketing-local-hub-22052026\resources\themes\guest\mlhubfrontend/resources/views/partials/marketing-nav-mobile.blade.php ENDPATH**/ ?>