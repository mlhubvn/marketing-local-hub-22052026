<?php

return [
    'name' => 'AdminMarketplace',
];
