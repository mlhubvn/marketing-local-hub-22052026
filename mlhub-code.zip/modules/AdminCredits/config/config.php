<?php

return [
    'name' => 'AdminCredits',
];
