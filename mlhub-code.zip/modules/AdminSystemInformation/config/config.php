<?php

return [
    'name' => 'AdminSystemInformation',
];
