<?php

return [
    'name' => 'AdminBlogs',
];
