<?php

return [
    'name' => 'AdminBlogCategories',
];
