<?php

return [
    'name' => 'AdminCaptcha',
];
