<?php

return [
    'name' => 'AdminPaymentHistory',
];
