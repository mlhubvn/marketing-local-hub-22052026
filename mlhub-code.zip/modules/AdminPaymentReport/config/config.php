<?php

return [
    'name' => 'AdminPaymentReport',
];
