<?php

return [
    'name' => 'AdminCrons',
];
