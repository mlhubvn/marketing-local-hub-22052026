<?php

return [
    'name' => 'AdminManualPayments',
];
