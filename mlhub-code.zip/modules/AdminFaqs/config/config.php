<?php

return [
    'name' => 'AdminFaqs',
];
