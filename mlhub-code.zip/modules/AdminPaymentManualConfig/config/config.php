<?php

return [
    'name' => 'AdminPaymentManualConfig',
];
