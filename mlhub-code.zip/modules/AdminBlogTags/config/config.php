<?php

return [
    'name' => 'AdminBlogTags',
];
