<?php

return [
    'name' => 'AdminAffiliate',
];
