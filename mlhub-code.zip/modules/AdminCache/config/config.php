<?php

return [
    'name' => 'AdminCache',
];
