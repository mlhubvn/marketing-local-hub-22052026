<?php

return [
    'name' => 'AdminNotifications',
];
