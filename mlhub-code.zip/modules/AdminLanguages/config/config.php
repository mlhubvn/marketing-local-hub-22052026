<?php

return [
    'name' => 'AdminLanguages',
];
