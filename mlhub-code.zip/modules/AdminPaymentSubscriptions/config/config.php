<?php

return [
    'name' => 'AdminPaymentSubscriptions',
];
