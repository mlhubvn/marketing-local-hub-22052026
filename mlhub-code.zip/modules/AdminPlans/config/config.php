<?php

return [
    'name' => 'AdminPlans',
];
