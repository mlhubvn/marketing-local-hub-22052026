<?php

return [
    'name' => 'AdminCoupons',
];
