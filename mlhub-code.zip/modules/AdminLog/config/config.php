<?php

return [
    'name' => 'AdminLog',
];
