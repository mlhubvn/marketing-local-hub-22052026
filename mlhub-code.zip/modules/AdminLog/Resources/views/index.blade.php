<section class="w-full">
    <x-settings.layout :heading="__('Logs')" :subheading="__('View, download, and clear application log files.')" content-width-class="max-w-full">
        <div class="space-y-6">
            @if ($statusMessage)
                <x-ui.alert :variant="$statusVariant" :title="$statusVariant === 'success' ? __('Completed') : __('Action failed')" :description="$statusMessage" />
            @endif

            @if (empty($files))
                <x-ui.alert variant="info" inline :title="__('No log files')" :description="__('There are no .log files in storage/logs yet.')" />
            @elseif ($activeFile && $selectedFile)
                <x-theme.section-card
                    :title="$activeFile['name']"
                    :description="$activeFile['size_human'].' · '.$activeFile['modified']"
                    body-class="p-6"
                >
                    <div class="mb-4 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
                        <label class="flex min-w-[min(100%,20rem)] flex-col gap-1.5 text-sm">
                            <span class="font-medium text-slate-600 dark:text-slate-300">{{ __('Log file') }}</span>
                            <select
                                wire:change="selectFile($event.target.value)"
                                class="h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
                            >
                                @foreach ($files as $file)
                                    <option value="{{ $file['name'] }}" @selected($selectedFile === $file['name'])>{{ $file['name'] }} ({{ $file['size_human'] }})</option>
                                @endforeach
                            </select>
                        </label>
                    </div>

                    <div
                        class="mb-4 flex flex-wrap items-center gap-3"
                        x-data="{
                            copied: false,
                            async copyLog() {
                                const el = document.getElementById('admin-log-preview');
                                const text = el?.innerText?.trim() ?? '';
                                if (text === '') {
                                    return;
                                }
                                try {
                                    await navigator.clipboard.writeText(text);
                                    this.copied = true;
                                    setTimeout(() => this.copied = false, 1400);
                                } catch (e) {
                                    // ignore — clipboard may be blocked without HTTPS
                                }
                            },
                        }"
                    >
                        <x-ui.button type="button" variant="outline" wire:click="refresh" wire:loading.attr="disabled">
                            <i class="fa-light fa-rotate-right"></i>
                            <span>{{ __('Refresh') }}</span>
                        </x-ui.button>

                        <x-ui.button type="button" variant="secondary" wire:click="download('{{ $selectedFile }}')" wire:loading.attr="disabled">
                            <i class="fa-light fa-download"></i>
                            <span>{{ __('Download') }}</span>
                        </x-ui.button>

                        <x-ui.button type="button" variant="outline" x-on:click="copyLog()">
                            <i class="fa-light" x-bind:class="copied ? 'fa-check' : 'fa-copy'"></i>
                            <span x-text="copied ? @js(__('Copied')) : @js(__('Copy'))"></span>
                        </x-ui.button>

                        <x-ui.dialog wire:key="log-clear-{{ $selectedFile }}" :title="__('Clear this log file?')" :description="__('This empties the file contents but keeps the file. This cannot be undone.')" width="sm">
                            <x-slot:trigger>
                                <x-ui.button type="button" variant="outline">
                                    <i class="fa-light fa-eraser"></i>
                                    <span>{{ __('Clear') }}</span>
                                </x-ui.button>
                            </x-slot:trigger>

                            <x-slot:footer>
                                <div class="flex justify-end gap-3">
                                    <x-ui.button type="button" variant="outline" x-on:click="open = false">{{ __('Cancel') }}</x-ui.button>
                                    <x-ui.button type="button" variant="secondary" wire:click="clearFile('{{ $selectedFile }}')" x-on:click="open = false">{{ __('Continue') }}</x-ui.button>
                                </div>
                            </x-slot:footer>
                        </x-ui.dialog>

                        <x-ui.dialog wire:key="log-delete-{{ $selectedFile }}" :title="__('Delete this log file?')" :description="__('This permanently removes the file. Laravel will create a new one on the next log write.')" width="sm">
                            <x-slot:trigger>
                                <x-ui.button type="button" variant="danger">
                                    <i class="fa-light fa-trash"></i>
                                    <span>{{ __('Delete') }}</span>
                                </x-ui.button>
                            </x-slot:trigger>

                            <x-slot:footer>
                                <div class="flex justify-end gap-3">
                                    <x-ui.button type="button" variant="outline" x-on:click="open = false">{{ __('Cancel') }}</x-ui.button>
                                    <x-ui.button type="button" variant="danger" wire:click="deleteFile('{{ $selectedFile }}')" x-on:click="open = false">{{ __('Delete') }}</x-ui.button>
                                </div>
                            </x-slot:footer>
                        </x-ui.dialog>
                    </div>

                    <div
                        wire:ignore
                        class="relative"
                        x-data="{
                            loading: true,
                            error: '',
                            async loadPreview(file, lines) {
                                const el = document.getElementById('admin-log-preview');
                                if (! el || ! file) {
                                    return;
                                }

                                this.loading = true;
                                this.error = '';

                                const url = new URL(@js($previewUrl), window.location.origin);
                                url.searchParams.set('file', file);
                                url.searchParams.set('lines', String(lines));

                                try {
                                    const response = await fetch(url.toString(), {
                                        headers: { Accept: 'text/plain' },
                                        credentials: 'same-origin',
                                    });

                                    if (! response.ok) {
                                        throw new Error('preview_failed');
                                    }

                                    const text = await response.text();
                                    el.textContent = text.trim() === '' ? @js(__('This log file is empty.')) : text;
                                } catch (e) {
                                    el.textContent = '';
                                    this.error = @js(__('Could not load log preview. Try Refresh or Download.'));
                                } finally {
                                    this.loading = false;
                                }
                            },
                        }"
                        x-init="loadPreview(@js($selectedFile), @js($lines))"
                        x-on:log-preview-reload.window="loadPreview($event.detail.file, $event.detail.lines)"
                    >
                        <div
                            x-show="loading"
                            x-cloak
                            class="absolute inset-0 z-10 flex items-center justify-center rounded-lg bg-zinc-950/90 text-sm text-zinc-300"
                        >
                            <i class="fa-light fa-spinner-third fa-spin mr-2"></i>
                            <span>{{ __('Loading log…') }}</span>
                        </div>
                        <p x-show="error !== ''" x-cloak x-text="error" class="mb-2 text-sm text-amber-300"></p>
                        <pre id="admin-log-preview" class="max-h-[32rem] min-h-[12rem] overflow-auto rounded-lg bg-zinc-950 p-4 text-xs leading-relaxed text-zinc-100 whitespace-pre-wrap break-words"></pre>
                    </div>
                </x-theme.section-card>
            @endif

            <x-ui.alert
                variant="warning"
                inline
                :title="__('Security note')"
                :description="__('Log files can contain sensitive data (stack traces, database hosts, user IDs, emails). Only admins can open this page — never copy logs into the public folder.')"
            />
        </div>
    </x-settings.layout>
</section>
