<?php

return [
    'name' => 'AdminAITemplate',
];
