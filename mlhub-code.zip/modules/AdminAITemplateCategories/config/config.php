<?php

return [
    'name' => 'AdminAITemplateCategories',
];
